package pl.damiankaplon.atipera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtiperaApplicationTests {

    @Test
    void contextLoads() {
    }

}
